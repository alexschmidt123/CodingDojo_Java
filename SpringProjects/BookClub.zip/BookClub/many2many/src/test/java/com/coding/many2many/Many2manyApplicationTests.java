package com.coding.many2many;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Many2manyApplicationTests {

	@Test
	void contextLoads() {
	}

}
