package com.coding.many2many;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Many2manyApplication {

	public static void main(String[] args) {
		SpringApplication.run(Many2manyApplication.class, args);
	}

}
